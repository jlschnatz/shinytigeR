// add logo see https://stackoverflow.com/questions/78710175/
$(document).ready(function() {
    $(".navbar .container-fluid").prepend(
        "<img id='myImage' src='www/img_logo/tiger_logo_white.png' align='right' height='57.5px'>"
    );
});